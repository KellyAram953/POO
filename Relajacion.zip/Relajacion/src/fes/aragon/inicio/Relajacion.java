package fes.aragon.inicio;

public class Relajacion {
	    public static void main(String[] args) {
	        // Definir el sistema de ecuaciones lineales
	        double[][] valorX = {
	                {1, 0.25, 0},
	                {0.25, -1, 0.25},
	                {0, 0.25, -1},
	              //  {0, 0, -1, 3}
	        };

	        double[] residuo = {0.5, 1.5, 0.5};

	        // Parámetro de relajación (0 < omega < 2 para convergencia)
	        double x = 1.2;

	        // Número máximo de iteraciones
	        int maxIte = 1000;

	        // Llamar al método de Gauss-Seidel con relajación
	        double[] solucion = gaussSeidelRelajacion(valorX, residuo, x, maxIte);

	        // Mostrar la solución
	        System.out.println("Solución:");
	        for (int i = 0; i < solucion.length; i++) {
	            System.out.println("x" + (i + 1) + " = " + solucion[i]);
	        }
	    }

	    public static double[] gaussSeidelRelajacion(double[][] coeficientes,
	    		double[] b, double omega, int maxIteraciones) {
	        int n = b.length;
	        double[] x = new double[n];
	        double[] xAnterior = new double[n];

	        for (int iteracion = 0; iteracion < maxIteraciones; iteracion++) {
	            for (int i = 0; i < n; i++) {
	                // Calcular la suma de los términos anteriores
	                double sumaA = 0;
	                for (int j = 0; j < i; j++) {
	                    sumaA += coeficientes[i][j] * x[j];
	                }

	                // Calcular la suma de los términos posteriores
	                double sumaP = 0;
	                for (int j = i + 1; j < n; j++) {
	                    sumaP += coeficientes[i][j] * xAnterior[j];
	                }

	                // Calcular el nuevo valor de x[i] con relajación
	                x[i] = (1 - omega) * xAnterior[i] + (omega / coeficientes[i][i]) * (b[i] - sumaA - sumaP);
	            }

	            // Verificar la convergencia (puedes ajustar este criterio según tus necesidades)
	            if (convergencia(x, xAnterior)) {
	                break;
	            }

	            // Actualizar la solución anterior para la próxima iteración
	            System.arraycopy(x, 0, xAnterior, 0, n);
	        }

	        return x;
	    }

	    public static boolean convergencia(double[] x, double[] xAnterior) {
	        // Puedes ajustar este criterio según tus necesidades
	        double t = 1e-8;
	        for (int i = 0; i < x.length; i++) {
	            if (Math.abs(x[i] - xAnterior[i]) > t) {
	                return false;
	            }
	        }
	        return true;
	    }
	}
