package fes.aragon.inicio;

import java.util.Scanner;

public class RelajacionUno {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Ingrese el número de ecuaciones del sistema:");
	        int n = scanner.nextInt();

	        // Definir las matrices para coeficientes y términos independientes
	        double[][] c= new double[n][n];
	        double[] terIn = new double[n];

	        // Pedir al usuario que ingrese los coeficientes
	        System.out.println("Ingrese los coeficientes del sistema:");

	        for (int i = 0; i < n; i++) {
	            for (int j = 0; j < n; j++) {
	                System.out.print("Coeficiente A[" + (i + 1) + "][" + (j + 1) + "]: ");
	                c[i][j] = scanner.nextDouble();
	            }
	        }

	        // Pedir al usuario que ingrese los términos independientes
	        System.out.println("Ingrese los términos independientes:");

	        for (int i = 0; i < n; i++) {
	            System.out.print("Término B[" + (i + 1) + "]: ");
	            terIn[i] = scanner.nextDouble();
	        }

	        // Pedir al usuario que ingrese el parámetro de relajación
	        System.out.println("Ingrese el valor de delta: ");
	        double delta = scanner.nextDouble();

	        // Número máximo de iteraciones
	        System.out.println("Ingrese el número máximo de iteraciones: ");
	        int maxIt = scanner.nextInt();

	        // Llamar al método de Gauss-Seidel con relajación
	        double[] solucion = gaussSeidelRelajacion(c, terIn, delta, maxIt);

	        // Mostrar la solución
	        System.out.println("La solución es:");
	        for (int i = 0; i < solucion.length; i++) {
	            System.out.println("x" + (i + 1) + " = " + solucion[i]);
	        }

	        scanner.close();
	    }

	    public static double[] gaussSeidelRelajacion(double[][] cdos, double[] b, double deltados, int maxIte) {
	    	 int n = b.length;
		        double[] x = new double[n];
		        double[] xAnterior = new double[n];

		        for (int iteracion = 0; iteracion < maxIte; iteracion++) {
		            for (int i = 0; i < n; i++) {
		                // Calcular la suma de los términos anteriores
		                double sumaA = 0;
		                for (int j = 0; j < i; j++) {
		                    sumaA += cdos[i][j] * x[j];
		                }

		                // Calcular la suma de los términos posteriores
		                double sumaP = 0;
		                for (int j = i + 1; j < n; j++) {
		                    sumaP += cdos[i][j] * xAnterior[j];
		                }

		                // Calcular el nuevo valor de x[i] con relajación
		                x[i] = (1 - deltados) * xAnterior[i] + (deltados / cdos[i][i]) 
		                		* (b[i] - sumaA - sumaP);
		            }

		            // Verificar la convergencia 
		            if (convergenciaSuficiente(x, xAnterior)) {
		                break;
		            }// Actualizar la solución anterior para la próxima iteración
		            System.arraycopy(x, 0, xAnterior, 0, n);
		        }

		        return x;
		    }
	    

	    public static boolean convergenciaSuficiente(double[] x, double[] xAnterior) {
	    	double t = 1e-8;
	        for (int i = 0; i < x.length; i++) {
	            if (Math.abs(x[i] - xAnterior[i]) > t) {
	                return false;
	            }
	        }
	        return true;
	    }
	    }

