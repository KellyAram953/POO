package fes.aragon.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ConejoController implements Initializable {

    @FXML
    private Button btnDatos;

    @FXML
    private Button btnOperaciones;

    @FXML
    private Button btnRegresar;

    @FXML
    private Button btnResultado;

    @FXML
    private Label lblr;

    @FXML
    private TextArea txaOperacion;

    @FXML
    private Text txtd;

    @FXML
    private TextField txtd1;

    @FXML
    private TextField txtd2;

    @FXML
    private TextField txtd3;

    @FXML
    private TextField txtresultado;
    
    @FXML
    private TextField txterror;

    @FXML
    void datos(ActionEvent event) {
    	this.txtd1.setVisible(true);
		this.txtd2.setVisible(true);
		this.txtd3.setVisible(true);
		this.txterror.setVisible(true);
    }

    @FXML
    void operaciones(ActionEvent event) {
    	this.txaOperacion.setVisible(true);
    }

    @FXML
    void regresar(ActionEvent event) {
    	this.salir();
    }

    @FXML
    void resultado(ActionEvent event) {
    	this.txtresultado.setVisible(true);
    }
    private void salir() {
    	Stage stage = (Stage)btnRegresar.getScene().getWindow();
    	stage.close();
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		this.txtd1.setVisible(false);
		this.txtd2.setVisible(false);
		this.txtd3.setVisible(false);
		this.txterror.setVisible(false);
		this.txaOperacion.setVisible(false);
		this.txtresultado.setVisible(false);
	}
   
}
