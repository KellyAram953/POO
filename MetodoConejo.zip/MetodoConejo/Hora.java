package fes.aragon.inicio;

import java.text.SimpleDateFormat;
import java.util.Date;

public class  Hora {
	public static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");

	public static void main(String[] args) {
		
		Date fechaActual = new Date();
		System.out.println(DateAString(fechaActual));

	}
	public static String DateAString(Date fecha) {
		String fechac = sdf.format(fecha);
		return fechac;
	}

}

