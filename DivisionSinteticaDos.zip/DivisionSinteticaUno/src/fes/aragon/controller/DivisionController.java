package fes.aragon.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public  class  DivisionController implements Initializable{

    @FXML
    private Button btnDatos;

    public TextField getTxtDivisor() {
		return txtDivisor;
	}

	public void setTxtDivisor(TextField txtDivisor) {
		this.txtDivisor = txtDivisor;
	}

	public TextField getTxtIngresaD() {
		return txtIngresaD;
	}

	public void setTxtIngresaD(TextField txtIngresaD) {
		this.txtIngresaD = txtIngresaD;
	}

	public TextField getTxtIngresad2() {
		return txtIIngresad2;
	}

	public void setTxtIngresad2(TextField txtIngresad2) {
		this.txtIIngresad2 = txtIngresad2;
	}

	public TextField getTxtd1() {
		return txtd1;
	}

	public void setTxtd1(TextField txtd1) {
		this.txtd1 = txtd1;
	}

	public TextField getTxtd2() {
		return txtd2;
	}

	public void setTxtd2(TextField txtd2) {
		this.txtd2 = txtd2;
	}

	public TextField getTxtd3() {
		return txtd3;
	}

	public void setTxtd3(TextField txtd3) {
		this.txtd3 = txtd3;
	}

	public TextField getTxtresultado() {
		return txtresultado;
	}

	public void setTxtresultado(TextField txtresultado) {
		this.txtresultado = txtresultado;
	}
	@FXML
    private Button btnDivisor;

    @FXML
    private Button btnEjecutar;

    @FXML
    private Button btnRegresar;
    
    @FXML
    private Button btnIniciar;

    @FXML
    private TextField txtDivisor;

    @FXML
    private TextField txtIngresaD;
    
    @FXML
    private TextField txtIIngresad2;

    @FXML
    private TextField txtd1;

    @FXML
    private TextField txtd2;

    @FXML
    private TextField txtd3;

    @FXML
    private TextField txtresultado;
    

    @FXML
    void datos(ActionEvent event) {
    	this.txtd1.setVisible(true);
		this.txtd2.setVisible(true);
		this.txtd3.setVisible(true);
    }

    @FXML
    void divisor(ActionEvent event) {
    	this.txtDivisor.setVisible(true);
		this.txtIngresaD.setVisible(true);
    }

    @FXML
    void ejecutar(ActionEvent event) {
    	this.txtIIngresad2.setVisible(true);
		this.txtresultado.setVisible(true);
		//this.txtresultado.setEditable(false);
		
    }

    @FXML
    void regresar(ActionEvent event) {
    	this.salir();
    
    }
    private void salir() {
    	Stage stage = (Stage)btnRegresar.getScene().getWindow();
    	stage.close();
    }

    

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		this.txtd1.setVisible(false);
		this.txtd2.setVisible(false);
		this.txtd3.setVisible(false);
		this.txtDivisor.setVisible(false);
		this.txtIngresaD.setVisible(false);
		this.txtIIngresad2.setVisible(false);
		this.txtresultado.setVisible(false);
		this.txtresultado.setEditable(false);
		this.txtIngresaD.setEditable(false);
		//this.txtd
			}
}
