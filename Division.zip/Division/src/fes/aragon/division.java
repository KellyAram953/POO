package fes.aragon;

import java.util.Iterator;
import java.util.Scanner;

public class division {

	public static void main(String[] args) {
		int e,num,i;
		int[] a = new int[10];
		int[] b = new int[10];
		Scanner teclado = new Scanner(System.in);
		System.out.println("Elemtos a dividir: " );
		e= teclado.nextInt();
		 System.out.println("¿Entre qué número lo quieres dividir?: ");
		 num = teclado.nextInt(); 
		 for (i = 1; i <= e; i++) {
			 System.out.print("Dame el elemento " + i);
			 a[i] = teclado.nextInt();	
			//a[i];
		}
		
		 System.out.println(a[1]);
		 for(i=1; i<=e; i++) {
			    b[i]=a[1];
			    }
		 for(i=2; i<=e; i++) {
			    b[i]= num*(b[i]);
			    num = b[i]+a[i];
			    System.out.println(num);
			    }
		// System.out.println(num);
	}}
