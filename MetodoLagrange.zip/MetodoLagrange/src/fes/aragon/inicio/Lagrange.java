package fes.aragon.inicio;

import java.util.Scanner;

public class Lagrange {
  public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Ingrese el numero de coeficientes de la tabla:");
	        int n = scanner.nextInt();

	        double[] x = new double[n];
	        double[] y = new double[n];

	        // Pedir al usuario que ingrese los puntos de interpolación
	        System.out.println("Ingrese los valores de x:");

	        for (int i = 0; i < n; i++) {
	            System.out.print("x[" + i + "]: ");
	            x[i] = scanner.nextDouble();
	        }

	        System.out.println("Ingrese los valores de y:");

	        for (int i = 0; i < n; i++) {
	            System.out.print("y[" + i + "]: ");
	            y[i] = scanner.nextDouble();
	        }

	        // Pedir al usuario que ingrese el valor de x para interpolar
	        System.out.println("Ingrese el valor de x para interpolar:");
	        double valorX = scanner.nextDouble();

	        // Calcular el resultado utilizando el método de  Lagrange
	        double resultado = interpolacionLagrange(x, y, valorX);

	        // Mostrar el resultado
	        System.out.println("Cuando X es igual a  " + valorX + " su valor en Y es " + resultado%2);

	        scanner.close();
	    }

	    public static double interpolacionLagrange(double[] x, double[] y, double valorX) {
	        double resultado = 0;

	        for (int i = 0; i < x.length; i++) {
	            double termino = y[i];

	            for (int j = 0; j < x.length; j++) {
	                if (j != i) {
	                    termino = termino * (valorX - x[j]) / (x[i] - x[j]);
	                }
	            }

	            resultado += termino;
	        }

	        return resultado;
	    }
	}
